mapa = {
'6': 'f',
'3' : 'e',
'50': 'l',
'1' : 'i',
'26' : 'z',
'mm' : '2000',
'r' : '18',
}
while True:
 pergunta = input('Digite o código: ')
 if pergunta in mapa:
  letra1 = mapa['mm']
  var1 = letra1.replace('2000',' 20')
  partes = mapa['6'], mapa['3'], mapa['50'], mapa['1'], mapa['26'], var1, mapa['r'] , '!'
  uniao = ''.join(partes)
  print(uniao)
  break
 elif pergunta == '6350126mmr':
  letra1 = mapa['mm']
  var1 = letra1.replace('2000',' 20')
  partes = mapa['6'], mapa['3'], mapa['50'], mapa['1'], mapa['26'], var1, mapa['r'] , '!'
  uniao = ''.join(partes)
  print(uniao)
  break

 print('Digite o código novamente')
